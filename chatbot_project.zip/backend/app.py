import os, json, time, logging
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import redis, openai
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY")
db = SQLAlchemy(app)
CORS(app)
r = redis.from_url(os.getenv("REDIS_URL"), decode_responses=True)
openai.api_key = os.getenv("OPENAI_API_KEY")

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50))
    role = db.Column(db.String(10))
    content = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

db.create_all()

def push_memory(uid, role, content, limit=12):
    key = f"chat:{uid}"
    r.rpush(key, json.dumps({"role":role,"content":content}))
    r.ltrim(key, -limit, -1)

def get_memory(uid):
    key = f"chat:{uid}"
    items = r.lrange(key, 0, -1)
    return [json.loads(x) for x in items] if items else []

@app.route("/api/v1/chat", methods=["POST"])
def chat():
    data = request.json
    uid = data.get("user_id","guest")
    msg = data.get("message","")
    if not msg: return jsonify({"error":"empty message"}),400

    # memory
    history = get_memory(uid)
    messages = [{"role":"system","content":"You are a helpful assistant."}]
    messages.extend(history)
    messages.append({"role":"user","content":msg})

    try:
        resp = openai.ChatCompletion.create(
            model=os.getenv("MODEL_NAME","gpt-4.1"),
            messages=messages,
            temperature=float(os.getenv("TEMPERATURE",0.3)),
            max_tokens=int(os.getenv("MAX_TOKENS",600))
        )
        reply = resp["choices"][0]["message"]["content"]
        # store
        db.session.add(Message(user_id=uid,role="user",content=msg))
        db.session.add(Message(user_id=uid,role="assistant",content=reply))
        db.session.commit()
        push_memory(uid,"user",msg)
        push_memory(uid,"assistant",reply)
        return jsonify({"reply":reply})
    except Exception as e:
        logging.exception("OpenAI error")
        return jsonify({"error":"OpenAI failed","detail":str(e)}),500

@app.route("/api/v1/history/<uid>")
def history(uid):
    return jsonify({"messages":get_memory(uid)})

if __name__=="__main__":
    app.run(host="0.0.0.0",port=5000)
