import React, {useState,useEffect,useRef} from "react";

const API="/api/v1/chat";

function Msg({role,content}){
  const me=role==="user";
  return (
    <div style={{display:"flex",justifyContent:me?"flex-end":"flex-start"}}>
      <div style={{
        background:me?"#3498db":"#ecf0f1",
        color:me?"#fff":"#333",
        padding:"8px 12px",borderRadius:8,margin:4,maxWidth:"70%"
      }}>{content}</div>
    </div>
  );
}

export default function App(){
  const [msgs,setMsgs]=useState([]);
  const [text,setText]=useState("");
  const ref=useRef();

  useEffect(()=>{ref.current?.scrollIntoView({behavior:"smooth"});},[msgs]);

  const send=async()=>{
    if(!text.trim()) return;
    setMsgs(m=>[...m,{role:"user",content:text}]);
    const res=await fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({user_id:1,message:text})});
    const d=await res.json();
    setMsgs(m=>[...m,{role:"assistant",content:d.reply||"Error"}]);
    setText("");
  };

  return (
    <div style={{maxWidth:600,margin:"auto",padding:16}}>
      <h2>AI Chatbot</h2>
      <div style={{border:"1px solid #ccc",height:400,overflowY:"auto",padding:8}}>
        {msgs.map((m,i)=><Msg key={i} {...m}/>)}
        <div ref={ref}/>
      </div>
      <div style={{display:"flex",marginTop:8}}>
        <input value={text} onChange={e=>setText(e.target.value)} style={{flex:1,padding:8}} placeholder="Type..."/>
        <button onClick={send} style={{marginLeft:8,padding:"8px 16px"}}>Send</button>
      </div>
    </div>
  );
}
